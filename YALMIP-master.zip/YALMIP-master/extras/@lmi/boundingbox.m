function varargout = boundingbox(F,ops,x,fun_eval)
%BOUNDINGBOX Computes bounding box of a constraint
%
% If only one output is requested, only the symbolic model is returned
%  B = boundingbox(F)
%
% If three outputs are requested, numerical values are returned too
%  [B,L,U] = boundingbox(F)
%
% A second argument can be used to specificy solver settings
%  B = boundingbox(F,sdpsettings('solver','cplex'))
%
% A third argument can (should!) be used to obtain a bounding box in a
% particular set of variables, i.e. the bounding box of a projection.
% Unless you specify which variables you are computing the bounding box
% w.r.t, it will be very hard for you to understand which variables the
% values in L and U relate to
%  [B,L,U] = boundingbox(F,[],x)
% B will now be the box [L <= x <= U] (infinite bounds not included)

if nargin < 3 | isempty(x)
    x = recover(depends(F));
else
    x = x(:);
    if ~isa(x,'sdpvar')
        error('The third argument should be an SDPVAR obeject');
    end
end

if nargin < 2
    ops = sdpsettings('verbose',0);
end
if isempty(ops)
    ops = sdpsettings('verbose',0);
end
if ~isa(ops,'struct')
    error('The second argument should be an SDPSETTINGS struct (or empty)');
end

sol = solvesdp(F,[x;-x],ops);
n = length(x);
sols = {};
vals = {};
for i = 1:n
    xi = x(i);
    if isa(xi,'sdpvar')
        if sol.problem(i)==0          
            L(i,1) = double(xi,i);
            if nargin > 3
              sols{end+1} = double(x,i);
              vals{end+1} = double(fun_eval,i);
            end
        else
            L(i,1) = -inf;            
        end
        if sol.problem(n+i)==0           
            U(i,1) = double(xi,n+i);
            if nargin > 3
              sols{end+1} = double(x,n+i);
              vals{end+1} = double(fun_eval,n+i);
            end
        else
            U(i,1) = inf;
        end
    else
        L(i,1) = xi;
        U(i,1) = xi;
    end
end

% Only add finite bounds
Lf = find(~isinf(L));
Uf = find(~isinf(U));
B = [];
if ~isempty(Lf)
    xLf = x(Lf);
    if isa(xLf,'sdpvar')
        B = [B, (xLf >= L(Lf)):'Finite lower bounds'];
    end
end
if ~isempty(Uf)
    xUf = x(Uf);
    if isa(xUf,'sdpvar')
        B = [B, (xUf <= U(Uf)):'Finite upper bounds'];
    end
end
varargout{1} = B;
varargout{2} = L;
varargout{3} = U;
varargout{4} = sols;
varargout{5} = vals;