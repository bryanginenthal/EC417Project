function cx = getP(X)
%display           Overloaded

cx = X.P;
