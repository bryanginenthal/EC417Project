function x = horzcat(varargin)
% horzcat (overloaded)

x = cat(2,varargin{:});