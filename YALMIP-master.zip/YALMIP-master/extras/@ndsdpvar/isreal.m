function v = isreal(X)
% isreal (overloaded)

v = isreal(sdpvar(X));