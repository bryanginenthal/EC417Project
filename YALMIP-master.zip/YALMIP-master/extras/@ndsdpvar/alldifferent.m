function t = alldifferent(X)
% alldifferent (overloaded)

t = alldifferent(sdpvar(X));